# Optical Interconnect Market — Dataset

This dataset contains structured metadata and derived summaries from the public landing page of the Optical Interconnect Market report (SE3569) by Next Move Strategy Consulting.

It does **not** contain paid PDF material — only publicly visible information transformed into a research‑friendly dataset.

Contents:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- table_of_contents.md
- README.md
- license.txt
